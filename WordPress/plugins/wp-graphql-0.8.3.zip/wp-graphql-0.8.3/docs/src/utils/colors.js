export default {
  primary: '#0e2339',
  primaryLight: '#f7901d',
}
